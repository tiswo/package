---
name: Question about rqlite
about: Ask a question about rqlite and its use
title: ''
labels: ''
assignees: ''

---

Before you ask a question here about rqlite, consider instead posting your question to Slack or the rqlite Google Group. That way you can benefit from that larger community's expertise.

- https://rqlite.slack.com (join directly at https://www.philipotoole.com/join-rqlite-slack)
- https://groups.google.com/g/rqlite

You can also start a discussion on the rqlite GitHub discussion page.

https://github.com/rqlite/rqlite/discussions
