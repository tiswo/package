# circleci-primary

Custom Docker image for faster testing on CircleCI.

## To build
```bash
docker build -t rqlite/circleci-primary:<tag> .
docker push rqlite/circleci-primary:<tag>
```