// Package cluster supports intracluster control messaging.
package cluster
