/*
Package tcp provides the internode communication network layer.
*/
package tcp
