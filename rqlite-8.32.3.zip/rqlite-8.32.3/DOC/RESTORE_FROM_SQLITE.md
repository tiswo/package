# Restoring directly from SQLite
Visit [rqlite.io](https://rqlite.io) for the latest documentation.
