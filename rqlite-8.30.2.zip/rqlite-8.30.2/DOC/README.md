# rqlite documentation
Visit [rqlite.io](https://rqlite.io) for the latest documentation.

These docs are no longer updated, and remain here for legacy reference.
