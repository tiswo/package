# Running rqlite on Kubernetes
See the [official Kubernetes guide for rqlite](https://rqlite.io/docs/guides/kubernetes/).
