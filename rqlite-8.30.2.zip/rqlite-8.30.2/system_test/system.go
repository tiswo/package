// Package system supports running end-to-end type testing of rqlite
package system
