# Monitoring rqlite
Check out the [monitoring guide](https://rqlite.io/docs/guides/monitoring-rqlite/).
